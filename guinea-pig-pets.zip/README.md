# 五隻天竺鼠寵物素材

本包含酸奶（像素版）、酸奶、花蛤蜊（小花）、烤肉、椒麻雞。每隻寵物資料夾中都有完整 spritesheet.png 與 pet.json；設定中的圖片路徑是相對路徑。小花為 v1 九列格式，其他四隻為 v2 十一列格式。

請至 https://github.com/GuineaP/guinea-pig-pets 查看預覽、公開領養連結、使用方式、技能下載與分享條件。

如使用完整圖檔重新匯入，請先驗證格式；不要用縮圖替代完整 spritesheet.png。SHA256SUMS 可核對本包內容；manifest.json 列有每隻寵物的格式、完整圖檔雜湊及公開領養連結。

歡迎在自己的 ChatGPT 或 Codex 中使用；轉貼請保留來源，修改請標示，商業利用或另外販售請先取得同意。
