# Photo identity and QA gates

## Identity-map template

At every gate, check mapped coat locations, exactly two forelimbs and two hindlimbs (natural occlusion allowed), and every normally visible eye or deliberately closed eyelid. Reuse an explicit approval for the same unchanged reviewed result; do not request it again.

Write observations before prompts:

```markdown
# <pet name> photo identity map

## Direct observations
- Body shape and hair:
- Head/face base color:
- Eye, ear, nose, and feet:

## Coat regions and adjacency
| Region | Color | Anatomical anchor | Must touch | Must not touch | Evidence angles |
|---|---|---|---|---|---|
| A | | | | | |

## Angle behavior
- Screen-right profile:
- Screen-left profile:
- Looking up:
- Looking down:
- Top/front evidence:

## Inferences
- Plausible but not directly visible (cite supporting evidence):

## Unknowns and conflicts
- Not visible or conflicting:
```

Describe patch topology with landmarks. For example, "white collar begins behind the ear and touches the throat" is useful; "white near the head" is too loose.

## Gate A: canonical identity

- [ ] Character resembles the photos before style embellishment.
- [ ] Canonical uses the requested detailed pixel-art style at native size and integer nearest-neighbor zoom.
- [ ] Rendering reference controls pixel treatment only; its stripes and facial markings were not copied.
- [ ] Working pixel density, palette ramps and contour treatment are recorded.
- [ ] Every major coat boundary is anchored to the mapped anatomy.
- [ ] No invented face blaze, mask, stripe, saddle, or extra band.
- [ ] Left/right asymmetry is preserved or explicitly unknown.
- [ ] User approved the identity map and canonical sprite.

## Gate B: standard rows

- [ ] Exactly the required frame counts and order.
- [ ] No frame shows more than two front paws and two hind feet.
- [ ] A raised paw replaces a planted paw; it is not a fifth limb.
- [ ] Every normally visible eye is readable in every frame, including the second eye where exposed; deliberate closure has a correctly positioned eyelid.
- [ ] Coat-region adjacency stays unchanged across all frames.
- [ ] Fur-cluster size, palette treatment and pixel contour remain stable; no blurred scaling or temporal pixel noise.
- [ ] Contact-sheet face, body, and foot crops were visually reviewed.
- [ ] User approved the standard contact sheet.

## Gate C: directions

- [ ] Four cardinals are semantically clear and natural.
- [ ] Up/down do not use a forced front-facing pose unless supported by the references.
- [ ] Foreshortening compresses markings without moving them to another anatomical region.
- [ ] Screen-left and screen-right are viewer coordinates.
- [ ] The four cardinals were approved before rows 9 and 10.
- [ ] All 16 directions form a smooth ordered loop without identity drift.

## Gate D: final atlas and upload

- [ ] v2 atlas dimensions, rows, cells, transparency, and required frames validate.
- [ ] Chroma cleanup was applied exactly once to the final assembled atlas.
- [ ] Final contact sheet still passes limb, eye, and coat-topology review.
- [ ] Pixel edges and clusters remain crisp after extraction, registration and final chroma cleanup; review both native and integer-zoom views.
- [ ] Every animation was watched, not only inspected as stills.
- [ ] Final direction sheet and continuity review pass.
- [ ] Pets MCP validation passes.
- [ ] User approved the final review before upload.
- [ ] Pet creation, selection, and list verification succeed.

## Correction routing

- One malformed frame but stable row identity: regenerate the whole affected row with a narrower pose constraint.
- Same marking error across rows: correct the identity map and canonical sprite, then rebuild downstream rows.
- Direction-only marking migration: repair the cardinal anchor first, then rebuild both direction rows.
- User says "this drifted": stop generation, identify the exact landmark relationship that changed, re-open the source photos, and update the identity map before retrying.
