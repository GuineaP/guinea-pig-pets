# Pixel rendering contract

## Reference interpretation

Treat the supplied example as a detailed retro-game animal sprite: natural low oval proportions, warm light on clustered fur, small folded ears and paws, dark readable eyes, and crisp stepped contour transitions. Prefer medium-to-fine pixel density over a coarse icon or exaggerated chibi head. Keep a controlled set of color ramps with enough contrast to preserve the photo identity map. Do not impose an arbitrary 16-color palette or 32×32 grid when it erases identifying markings.

Use this reference for mark-making and pixel density only. Its dark back stripes, white facial region, individual anatomy and dark background belong to the example. Recover the new animal's coat boundaries, body shape, hair length and asymmetry from its own photos. In particular, preserve any mapped separator between a head-side white region and a rear body band.

Use the current user-supplied style image when available. If a reference image is missing in a new conversation, distinguish that from missing identity photos; describe the known rendering cues and do not claim to have re-inspected unavailable pixels.

## Generation and consistency

- Set the upstream run preset to `pixel`; include the specific rendering cues above rather than relying on that one word.
- Use imagegen for every new or edited animal raster. Generate intentional pixel art from the identity photographs; posterizing, dithering or downsampling a realistic render alone does not establish this style.
- Choose a working pixel density appropriate to a 192×208 cell, review it at native size, and record it with the canonical approval. Keep the same apparent fur-cluster size, outline treatment, lighting and color ramps across frames and direction rows.
- Favor stable connected pixel clusters over random one-pixel fur noise. Keep eye placement readable; when a second eye should be visible, include it. A deliberate blink has a correctly located eyelid rather than a blank face.
- Simplify texture before simplifying identifying anatomy or merging coat regions. Retain exactly two forelimbs and two hindlimbs, with natural occlusion allowed.
- Keep a clean transparent background or removable contrasting chroma. A charcoal preview background is optional; do not bake it, a ground shadow, glow or screenshot UI into the uploaded sprite.

## Pixel-safe deterministic stages

Use nearest-neighbor when resizing pet pixels. Integer enlargement is for review; do not change the final atlas contract. Keep shared row/atlas scale, fixed support registration and intentional jump displacement. Do not fit each pose separately to fill its cell.

Check the actual upstream scripts before using them: generic presets or a `pixel` prompt do not guarantee pixel-safe extraction. If a helper hardcodes smoothing, use an available pixel mode or a minimal rendering-only adapter that changes interpolation while preserving the official extraction, geometry, assembly and validation logic. Keep structural and quality validators unchanged and run them normally. Do not compensate for blurry edges by adding an invented pixelation pass and declaring success.

Inspect after extraction, registration and chroma cleanup. Reject blurred fur clusters, gray/green edge halos, mixed pixel densities, eye loss, merged color separators, and noisy temporal pixel shimmer. Preserve the raw generated art and rejected versions.

## Example handoff

> Detailed natural-proportion pixel-art guinea pig, matching the approved reference's clustered fur, controlled warm color ramps and crisp stepped edges. Use this animal's original photographs for its exact markings and anatomy. Keep a low oval body, small folded ears, exactly four limbs and readable eyes. Preserve every mapped coat-region boundary and separator; do not copy the style example's stripes or facial blaze. Maintain the approved pixel density across this whole coherent row. No photorealistic/3D rendering, blur, smooth painted contours, props or detached effects.

Confirm pixel style and photo identity in the single canonical approval gate. Keep the existing standard-row, cardinal and final-upload gates; honor an explicit approval already given for the same unchanged reviewed result instead of asking again.
