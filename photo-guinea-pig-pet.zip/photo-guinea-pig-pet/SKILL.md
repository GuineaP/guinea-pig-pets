---
name: photo-guinea-pig-pet
description: Create a photo-faithful pixel-art guinea-pig pet for ChatGPT Work Pets with staged coat-pattern, pixel-style, anatomy, motion, and direction QA. Use when the user supplies guinea-pig photos or video and wants a custom pet or a series of pets in one established visual style; do not use for standalone illustrations or pets for other apps.
---

# Photo-faithful pixel-art guinea-pig pet

Use `work-pets:create-pet` for the current v2 atlas contract, official scripts, preview, validation, upload, creation, selection, and verification. Use `imagegen` for every generated or edited raster sprite. Follow both skills in addition to this identity-control workflow.

Default to **detailed natural-proportion pixel art** inspired by the user's supplied reference: warm, softly shaded fur rendered with deliberate pixel clusters, crisp stepped contours, compact paws, and readable dark eyes. Read [references/pixel-style.md](references/pixel-style.md) before preparing a generation run. Set the upstream preparation preset to `pixel`; state the pixel style explicitly in every generation job. A later explicit user style choice takes precedence.

Use real photos/video for the animal's identity and the style reference only for rendering. Never copy the style example's black stripes, facial blaze, palette, or coat topology onto another guinea pig. When the task is only to edit this skill or explain it, stop after that work; do not generate, replace, upload, or select any pet.

At every stage, preserve mapped coat locations, exactly two forelimbs and two hindlimbs with natural occlusion allowed, and every eye that should normally be visible (or a correctly placed eyelid during an intentional blink). Honor explicit approval already given for the same unchanged reviewed result; re-open the affected gate only when that result changes.

The key invariant is **coat topology, not a verbal color list**. A white patch is defined by which anatomical landmarks and neighboring color regions it touches. It must remain attached to those landmarks when the head or body turns.

## 1. Audit the references before generating

Inspect every supplied still image. Convert readable HEIC files and sample useful video frames when possible. Record direct observations, inferences, and unknowns separately; do not replace a missing angle with a generic guinea-pig pattern.

Create `qa/photo-identity-map.md` using the template in [references/qa-gates.md](references/qa-gates.md). Record:

- body shape, hair length, ears, eyes, nose, and feet;
- each coat region's color, boundary, anatomical anchor, and neighboring regions;
- what changes or becomes occluded in left, right, front, top, up, and down views;
- uncertain or conflicting evidence.

Show the identity map and a single canonical three-quarter sprite to the user. **Pause for identity approval before generating animation rows.** If the user corrects a marking, update the map first and regenerate the canonical sprite; do not patch later rows around a bad base.

## 2. Lock the canonical identity

Choose a natural three-quarter pose that exposes the important markings. Generate a pixel-art canonical sprite directly from the photos and rendering reference. Do not use the previous photorealistic pet as the anatomy authority or merely shrink/filter a realistic image to claim pixel art. Preserve the animal's natural oval body and short neck rather than turning it into a generic round hamster.

Review the canonical sprite at actual pet size and at an integer nearest-neighbor enlargement. Confirm deliberate pixel clusters, stepped edges, readable eyes, four-limb construction, and all mapped coat separators. Record the working pixel density and palette treatment in `qa/pixel-style-lock.md` and use them across every row. Ask for style and identity approval together as the existing canonical gate; do not add a separate style-only confirmation.

Reject the canonical sprite if it invents a face blaze, mask, extra band, merged patches, missing separator color, or a silhouette contradicted by the photos. Keep rejected versions as evidence and clearly mark them rejected.

## 3. Build and review the nine standard rows

Generate rows in small waves. For every frame, enforce:

- exactly four limbs total; an expressive paw replaces the same planted paw rather than adding a limb;
- every normally visible eye must be readable; include the second eye whenever the pose exposes it, or a correctly placed eyelid when closure is intentional;
- identical coat topology and anchored boundaries;
- the approved pixel density, palette treatment, contour thickness, and clustered-fur style, with no realism drift or flickering pixel noise;
- stable scale and baseline, except for intentional jump height;
- no detached effects, props, text, shadows, or chroma contamination unless the base identity requires them.

Use nearest-neighbor for resizing approved pixel artwork and integer nearest-neighbor zoom for inspection. Preserve one shared scale and registration rather than resizing each pose independently. Inspect the installed upstream helpers' resampling behavior: use a supported pixel-art option or a narrowly scoped rendering adapter when required; never modify validators or invent a pass report. Reject softened, blurred, or mixed-density frames even if their dimensions validate.

Extract with the official scripts and create a full contact sheet. Also inspect enlarged crops of the face/head boundary, body markings, and feet. The programmatic inspector cannot detect six feet, a missing eye, or a white collar sliding onto the face.

**Pause for user approval of the standard contact sheet before direction work.** Regenerate an affected row as a whole when anatomy or identity drifts; do not splice mismatched final cells.

## 4. Approve cardinals before sixteen directions

Generate `000 up`, `090 screen-right`, `180 down`, and `270 screen-left` from the approved canonical identity. Keep the body planted and use a natural guinea-pig head/upper-body movement.

- Do not force up/down into a symmetrical front-facing ball unless the references support that view.
- Preserve coat-region adjacency under foreshortening. A neck band may compress behind the ears but may not migrate onto the forehead.
- Keep left and right independently faithful when markings are asymmetric; do not mirror by default.

Create an enlarged four-cardinal review image and **pause for approval**. Only then generate row 9, register it with the official script, and generate row 10 from the registered row 9 plus the approved cardinals.

## 5. Final visual and lifecycle gates

Read [references/qa-gates.md](references/qa-gates.md) and complete every gate. In addition to official atlas and Pets MCP validation, visually inspect:

- all 73 required frames in one contact sheet;
- all 16 directions at normal and enlarged scale;
- every animation preview in motion;
- face markings, eyes, limb count, and patch topology after chroma cleanup;
- pixel clusters and edge crispness after every resampling/cleanup stage, at native size and integer zoom.

If a repeated identity defect appears in multiple rows, return to the canonical identity stage. Do not keep repairing downstream symptoms.

Upload, create, and select the pet only after the user approves the final review. Verify selection with the Pets list tool. Preserve the final atlas, previews, validation reports, identity map, and rejected-version history in the Library output folder.

## Completion report

Report the active pet ID and selection result, link the final atlas and contact/direction review sheets, and summarize which manual QA gates passed. Do not describe a pet as complete when it has only passed file-dimension validation.
