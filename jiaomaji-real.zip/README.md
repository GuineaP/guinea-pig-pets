# 椒麻雞真實版

2026-11-03 新增的 ChatGPT 動態天竺鼠寵物。完整圖集為 v2，1536 × 2288，含九種動畫與十六個凝視方向。

直接領養：https://chatgpt.com/s/sharepet_6ae9730ed0748191b0a63af96bee59f7

專案與使用說明：https://github.com/GuineaP/guinea-pig-pets

此包是獨立的椒麻雞真實版，不覆蓋原本椒麻雞。寵物資料夾內有完整 spritesheet.png 與 pet.json，請保留兩個檔案在一起。設定使用相對路徑與公開用代號，不含帳號內部識別資料。匯入前請讓支援寵物功能的環境驗證格式。

歡迎在自己的 ChatGPT 或 Codex 使用；轉貼請保留來源，修改請標示，商業利用或另外販售請先取得同意。原始生活照片與製作紀錄不包含在本包中。
